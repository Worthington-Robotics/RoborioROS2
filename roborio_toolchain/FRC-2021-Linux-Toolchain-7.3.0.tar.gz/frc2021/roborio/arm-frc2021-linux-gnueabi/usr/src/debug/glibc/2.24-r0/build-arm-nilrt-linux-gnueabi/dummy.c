extern void __dummy__ (void);
void __dummy__ (void) { }
