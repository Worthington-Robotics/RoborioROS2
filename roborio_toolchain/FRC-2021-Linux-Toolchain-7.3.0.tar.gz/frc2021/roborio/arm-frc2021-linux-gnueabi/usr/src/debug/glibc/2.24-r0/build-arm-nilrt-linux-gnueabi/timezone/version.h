static char const TZVERSION[]="2.24";
