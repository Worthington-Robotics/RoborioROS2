#ifndef _LIBC_ABIS_H
#define _LIBC_ABIS_H 1

enum
{
  LIBC_ABI_DEFAULT = 0,
  LIBC_ABI_UNIQUE,
  LIBC_ABI_MAX
};

#endif
#define LIBC_ABIS_STRING "libc ABIs: UNIQUE\n"
